package org.studyeasy.vehicles;

import org.studyeasy.parent.Vehicle;

public class Truck extends Vehicle{
	public String	steering;
	public String	musicSystem;
	public String airConditioner;
	public int	container;


}
