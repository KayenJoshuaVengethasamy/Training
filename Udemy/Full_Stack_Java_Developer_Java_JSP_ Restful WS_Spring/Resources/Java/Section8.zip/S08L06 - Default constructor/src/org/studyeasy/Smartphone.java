package org.studyeasy;

public class Smartphone {
	private String brand = "Samsung";
 
	public String getBrand() {
		return brand;
	}
	

}
