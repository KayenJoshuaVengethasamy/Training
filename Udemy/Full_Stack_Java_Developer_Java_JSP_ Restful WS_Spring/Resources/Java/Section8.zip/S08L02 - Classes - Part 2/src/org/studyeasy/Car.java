package org.studyeasy;

public class Car {
	private String doors;
	private String engine;
	private String driver;
	private int speed;
	
	public void setSpeed(int speed){
		this.speed = speed;
	}
	public int getSpeed(){
		return speed;
	}
	

}
