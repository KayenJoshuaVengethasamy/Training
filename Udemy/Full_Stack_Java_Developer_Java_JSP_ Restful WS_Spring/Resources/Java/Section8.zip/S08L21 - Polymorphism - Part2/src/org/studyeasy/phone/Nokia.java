package org.studyeasy.phone;

public class Nokia extends Phone {

	public Nokia(String model) {
		super(model);
	}

}
