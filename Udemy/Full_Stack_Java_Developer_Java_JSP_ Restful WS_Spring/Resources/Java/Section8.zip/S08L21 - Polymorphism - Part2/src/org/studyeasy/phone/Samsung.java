package org.studyeasy.phone;

public class Samsung extends Phone{

	public Samsung(String model) {
		super(model);
	}
	
	public void features(){
		System.out.println("Andriod flagship");
	}
	
	

}
