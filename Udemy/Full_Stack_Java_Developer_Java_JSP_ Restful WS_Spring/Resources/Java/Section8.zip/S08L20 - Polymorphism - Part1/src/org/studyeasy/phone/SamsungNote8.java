package org.studyeasy.phone;

public class SamsungNote8 extends Phone{

	public SamsungNote8(String model) {
		super(model);
	}
	
	public void features(){
		System.out.println("Andriod flagship");
	}
	
	

}
