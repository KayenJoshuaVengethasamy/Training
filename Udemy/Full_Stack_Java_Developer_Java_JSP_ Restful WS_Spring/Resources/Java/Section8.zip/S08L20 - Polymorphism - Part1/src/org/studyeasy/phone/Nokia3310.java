package org.studyeasy.phone;

public class Nokia3310 extends Phone {

	public Nokia3310(String model) {
		super(model);
	}

}
