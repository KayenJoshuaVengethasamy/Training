package org.studyeasy;

public class Hello {

	public static void main(String[] args) {
		Car car = new Car();
		
		

	
	}

}
