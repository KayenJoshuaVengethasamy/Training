package org.studyeasy;

public enum Learning {
	COREJAVA,COLLECTIONS,GENERICS,JSPANDSERVLETS,MUILTITHREADING
	
}
