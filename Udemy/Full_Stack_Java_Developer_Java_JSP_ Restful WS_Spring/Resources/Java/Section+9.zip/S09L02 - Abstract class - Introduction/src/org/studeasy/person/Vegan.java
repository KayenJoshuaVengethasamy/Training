package org.studeasy.person;

public class Vegan extends Person{

	@Override
	public void eat() {
		System.out.println("Eats vegan food");
		
	}

}
