package org.studeasy.person;

public abstract class Person {
	
	public void speak(){
		System.out.println("Shares his/her thoughts.");
	}
	
	public abstract void eat();

}
