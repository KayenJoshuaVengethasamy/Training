package org.studyeasy.phone;

public interface Phone {
	String processor();
	String OS();
	int spaceInGB();

}
