package org.studeasy.blog;

public class Java {
	public void userFor(){
		System.out.println("Blogging..");
	}

}
