package org.studeasy.platform;

public class Java {
	public void usedFor(){
		System.out.println("Platform..");
	}

}
