package org.studeasy;

import org.studeasy.blog.Java;

public class App {

	public static void main(String[] args) {
		Java blog = new Java();
		blog.userFor();
	   

	}

}
