package org.studyeasy;

public class App {
	

	public static void main(String[] args) {
		
		int i;
		for(i=1; i<10; i++){
			System.out.println(i);
		}
		System.out.println("**********");
		System.out.println(i);

	}

}
