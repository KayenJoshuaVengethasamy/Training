package org.studyeasy;

public class B extends A{
	private final int x;


	public B(int x) {
		super();
		this.x = x;
	}

	public int getX() {
		return x;
	}

}
