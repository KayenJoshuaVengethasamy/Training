package org.studyeasy;

public class App {

	public static void main(String[] args) {
	
		B obj1 = new B(12);
		System.out.println(obj1.getX());
		
		
	}

}
