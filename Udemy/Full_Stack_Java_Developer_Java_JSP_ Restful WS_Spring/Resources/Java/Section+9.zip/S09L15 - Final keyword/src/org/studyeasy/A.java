package org.studyeasy;

public class A {

}
