package org.studyeasy.parent;

public class A {
	 public int x = 10;
	
	public void demo(){
		System.out.println("Value of x is "+x);
	}

}
