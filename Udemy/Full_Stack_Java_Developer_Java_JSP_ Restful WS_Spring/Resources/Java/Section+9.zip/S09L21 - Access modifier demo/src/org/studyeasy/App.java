package org.studyeasy;

import org.studyeasy.parent.A;

public class App {

	public static void main(String[] args) {
		
         new A().demo();
         int test =  new A().x;
         System.out.println(test);
	}

}
