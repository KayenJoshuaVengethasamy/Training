package org.studyeasy.child;

import org.studyeasy.parent.A;

public class B extends A{

}
