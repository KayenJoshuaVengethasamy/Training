package org.studeasy.person;

public interface LiveLife {
    void message();
}
