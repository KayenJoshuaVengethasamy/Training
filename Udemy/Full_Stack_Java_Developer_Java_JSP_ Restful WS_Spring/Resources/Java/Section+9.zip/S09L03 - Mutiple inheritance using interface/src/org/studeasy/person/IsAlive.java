package org.studeasy.person;

public interface IsAlive {
	void breathe();

}
