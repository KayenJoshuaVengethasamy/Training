package org.studyeasy;

public final class A {
	public  void india(){
		System.out.println("India is amazing!");
	}
	
	public  void USA(){
		System.out.println("USA is fantastic");
	}

}
