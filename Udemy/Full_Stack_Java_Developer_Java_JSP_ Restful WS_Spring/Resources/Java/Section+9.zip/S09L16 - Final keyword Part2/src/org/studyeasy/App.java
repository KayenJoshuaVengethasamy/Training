package org.studyeasy;

public class App {

	public static void main(String[] args) {
	
		B obj1 = new B();
		obj1.india();
		obj1.USA();
		
	}

}
