package org.studyeasy;

public class B{
	private final int x =1;


	public int getX() {
		return x;
	}

	public void india() {
		System.out.println("Hello India, what's up?");
	}

		public  void USA(){
		System.out.println("USA is fantastic");
	}
	

}
