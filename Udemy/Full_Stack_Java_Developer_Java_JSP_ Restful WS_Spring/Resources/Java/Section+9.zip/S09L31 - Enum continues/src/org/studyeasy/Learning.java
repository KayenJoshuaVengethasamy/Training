package org.studyeasy;

public enum Learning {
	COREJAVA(1),COLLECTIONS(2),GENERICS(3),JSPANDSERVLETS(4),MUILTITHREADING(5);
	
	public int value;

	private Learning(int value) {
		this.value = value;
	}
	
	
}
