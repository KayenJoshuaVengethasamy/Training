package org.studyeasy;

public class App {

	public static void main(String[] args) {
		
         Integer x = 3;
         Integer y = 2;
         
         System.out.println(x.compareTo(y));
 
	}

}
