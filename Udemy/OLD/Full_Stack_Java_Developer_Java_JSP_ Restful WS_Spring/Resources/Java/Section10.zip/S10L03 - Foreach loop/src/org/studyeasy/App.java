package org.studyeasy;

public class App {

	public static void main(String[] args) {
	
		String[] stringArray = {"Chaand","John","Pooja","Mia","Salim"};
		
		for(String name: stringArray){
			System.out.println(name);
		}	
	}

}
