package org.studyeasy;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a int value");
		int x = scan.nextInt();
		System.out.println(x);
		scan.close();

	}

}
