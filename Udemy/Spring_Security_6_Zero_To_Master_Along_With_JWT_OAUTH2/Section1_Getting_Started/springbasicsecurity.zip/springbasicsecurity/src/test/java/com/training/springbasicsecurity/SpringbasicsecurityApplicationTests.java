package com.training.springbasicsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbasicsecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
