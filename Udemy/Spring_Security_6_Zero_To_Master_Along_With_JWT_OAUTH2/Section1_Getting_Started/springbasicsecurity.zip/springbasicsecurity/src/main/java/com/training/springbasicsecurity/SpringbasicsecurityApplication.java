package com.training.springbasicsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbasicsecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbasicsecurityApplication.class, args);
	}

}
